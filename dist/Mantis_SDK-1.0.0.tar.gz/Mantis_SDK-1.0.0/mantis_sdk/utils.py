def format_response(response: dict) -> dict:
    """Helper function to format API responses."""
    return response
